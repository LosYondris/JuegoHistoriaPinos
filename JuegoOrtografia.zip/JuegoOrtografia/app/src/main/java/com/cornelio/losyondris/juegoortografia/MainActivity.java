package com.cornelio.losyondris.juegoortografia;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.GoogleAuthProvider;


public class MainActivity extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener {
Mtodos mtd = new Mtodos();
Juego jg = new Juego();
MediaPlayer mp;
GoogleApiClient googleSignInClient;
SignInButton signInButton;
private  static  int RC_SIGN_IN =  777;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ////boton de inicio Original
        Button d = (Button) findViewById(R.id.inicio);
        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mtd.SonidoGeneral(MainActivity.this, R.raw.boop);
                startActivity(new Intent(MainActivity.this, Juego.class));
                overridePendingTransition(R.anim.left_in,R.anim.left_out);
//                Intent fd = new Intent(MainActivity.this, Juego.class);


//                startActivity(fd);


            }
        });


        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        //googleSignInClient = GoogleSignIn.getClient(this, gso);
        googleSignInClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this,this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();

        SignInButton mBtn = (SignInButton) findViewById(R.id.sign_in_button);
        mBtn.setSize(SignInButton.SIZE_WIDE);
        mBtn.setColorScheme(SignInButton.COLOR_DARK);
        mBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent vst = new Intent(Auth.GoogleSignInApi.getSignInIntent(googleSignInClient));
               startActivityForResult(vst, RC_SIGN_IN);
            }
        });
    }


    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == RC_SIGN_IN){
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            hangleSignInResult(result);
        }
    }

    private void hangleSignInResult(GoogleSignInResult result) {
        if(result.isSuccess()){
            Log.i("TAG","Si");
            //GoogleSignInAccount account = result.getSignInAccount();
            llamarJuego();
        }else {
            Log.i("TAG","No");
        }
    }

    private void llamarJuego() {
        Intent ini = new Intent(MainActivity.this,Juego.class);
        ini.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(ini);
    }
}


