package com.cornelio.losyondris.juegoortografia;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.Locale;
import java.util.Random;

public class Juego extends AppCompatActivity {
    TextView tvPantalla, diaP,diaR, diaC, monedad, niveles;
    TextView mTiempo;
    Button confirmar;
   // MediaPlayer mp;
    RadioButton IdSrc ;
    RadioGroup radioGrup;
    View dview;
    Dialog mydialog;
    Mtodos mtd = new Mtodos();
    String timeLeftFormatted;
    int mMonedas = 0;
    private  static  final  long START_TIME_IN_MILLIS = 30000;
    boolean mTimerRunning;
    private  long mTimeLeftInMillis = START_TIME_IN_MILLIS;
    private CountDownTimer mCountDownTimer;
    int b = 0;
    String[] parts;
    int preguntaAct;
    private  int ids_answers[] = { R.id.a,R.id.b,R.id.c,R.id.d};
    private int Correctac_answer;
    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego);
        mydialog = new Dialog(this);
        mTimerRunning = false;
        niveles = (TextView) findViewById(R.id.idNivel);
        // mtd.SonidoFondo(Juego.this,R.raw.fondo_b);
        b = +1;
        playgame();
        tvPantalla = findViewById(R.id.pantalla_preg);
        confirmar = (Button) findViewById(R.id.btnConfirmar);
        radioGrup = (RadioGroup) findViewById(R.id.btnRadios);
        mTiempo = findViewById(R.id.id_tiempo);
        AsignarSonidoBTN();
        BtnHeader();
        monedad =(TextView) findViewById(R.id.id_monedad);


        confirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int Id = radioGrup.getCheckedRadioButtonId();
                int answ = -1;

                for (int c = 0; c< ids_answers.length; c++){
                    if(ids_answers[c] == Id){
                        answ = c;
                    }
                }
                if (answ ==  Correctac_answer) {
                    // Toast.makeText(Juego.this,"Correcto",Toast.LENGTH_LONG).show();
                    mtd.SonidoGeneral(Juego.this,R.raw.victoria);
                    preguntaAct++;
                    General_pregunta();

                    radioGrup.clearCheck(); // demarcar los btn
                    resetTimer(); //resectiar el tiempo
                  int f = Integer.parseInt(monedad.getText().toString());
                    f = f + 5; //TODO Cambiar el valor a 5
                  monedad.setText( String.valueOf(f));
                    ValorNIvel(f);
                }
                else {
                    // Toast.makeText(Juego.this,"InCorrecto",Toast.LENGTH_LONG).show();
                    mtd.SonidoGeneral(Juego.this,R.raw.error);
                    radioGrup.clearCheck();
                    resetTimer();

                    int f = Integer.parseInt(monedad.getText().toString());
                    int fx = f - 10;
                    if (fx <=0){
                        fx = 0;
                        monedad.setText( String.valueOf(fx));
                    }else {
                        monedad.setText( String.valueOf(fx));
                    }

                    //Log.i("TAG","valor: "+ f);

                }

                GuardarPref();

                //myRadioGrup(view);
                //Juego(mtds.poscion, view,IdSrc);
            }

        });




    }

    private void LeerPref() {
        SharedPreferences preferences = getSharedPreferences("BDPinos", Context.MODE_PRIVATE);
        String  Lmonedas = preferences.getString("BDmoneda","0");
        String Lnivel = preferences.getString("BDnivel","1");
        monedad.setText(Lmonedas);
        niveles.setText(Lnivel);

    }

    private void GuardarPref() {
        SharedPreferences preferences = getSharedPreferences("BDPinos", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();

        String Vmonedas = monedad.getText().toString();
        String Vnivel = niveles.getText().toString();

        editor.putString("BDmoneda",Vmonedas);
        editor.putString("BDnivel",Vnivel);
        editor.commit();
    }

    public void startTimer() {
        mCountDownTimer = new CountDownTimer(mTimeLeftInMillis, 500) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeLeftInMillis = millisUntilFinished;
                updateCountDownText();
               // Toast.makeText(Juego.this,"start", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFinish() {
                mTimerRunning = false;
               // Toast.makeText(Juego.this,"onFine", Toast.LENGTH_LONG).show();
            }
        }.start();

        mTimerRunning = true;
    }

    private void pauseTimer() {
        mCountDownTimer.cancel();
        mTimerRunning = false;
    }

    private void resetTimer() {
        mCountDownTimer.cancel();
        mTimerRunning = false;
        if(mTimerRunning == false){
            mTimeLeftInMillis = START_TIME_IN_MILLIS;
            updateCountDownText();
            startTimer();

        }
    }

    private void updateCountDownText() {
        int minutes = (int) (mTimeLeftInMillis / 1000) / 60;
        int seconds = (int) (mTimeLeftInMillis / 1000) % 60;
         timeLeftFormatted = String.format(Locale.getDefault(), ":%02d", seconds);
        //String timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
        mTiempo.setText(timeLeftFormatted);
        if(seconds == 0){
           // mtd.SonidoGeneral(Juego.this,R.raw.error);
            int mod = Integer.parseInt(monedad.getText().toString());
            if(findViewById(R.id.id_estrella2).getVisibility() == dview.INVISIBLE){
                findViewById(R.id.id_estrella3).setVisibility(dview.INVISIBLE);
                if(findViewById(R.id.id_estrella3).getVisibility() == dview.INVISIBLE && mod < 99){
                    finish();
                    //TODO - llamar el dialogo que diga tienes que esperar una hora para volver a jugar
                }else {
                    if(findViewById(R.id.id_estrella1).getVisibility() == dview.INVISIBLE){
                        Tienda();
                    }else {
                        Tienda();
                    }
                }

            }else {
                    UnaStrellaMeno();

            }

        }
    }


    private  void BtnHeader(){

        findViewById(R.id.id_btnAtra).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    finish();
                   mTimerRunning = false;
                   mCountDownTimer.cancel();
                    //onStop();
                   // Toast.makeText(Juego.this,"True", Toast.LENGTH_LONG).show();



                //mtd.SonidoGeneral(Juego.this,R.raw.boop);
                Intent btnAtra = new Intent(Juego.this, MainActivity.class);
                startActivity(btnAtra);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);

            }
        });

        findViewById(R.id.id_Regalo).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // mtd.SonidoGeneral(Juego.this,R.raw.boop);
               int valoMoneda = Integer.parseInt(monedad.getText().toString());
                if(valoMoneda >= 50){
                    Comodin_Regalo();
                }else {
                    MonedaInsuficiente();
                }

               // overridePendingTransition(R.anim.right_in,R.anim.right_out);
            }
        });

        findViewById(R.id.idNivel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // mtd.SonidoGeneral(Juego.this,R.raw.boop);
                Nivel();


            }
        });

        findViewById(R.id.idtienda).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // mtd.SonidoGeneral(Juego.this,R.raw.boop);
                Tienda();

            }
        });

        findViewById(R.id.id_lista).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Juego.this, List_Amigo.class));

            }
        });
    }

    private void General_pregunta() {
        SharedPreferences preferences = getSharedPreferences("BDPinos", Context.MODE_PRIVATE);
       int f = Integer.parseInt(preferences.getString("BDnivel","1"));

        switch (f){
            case 1:
                String[] nivel1 = getResources().getStringArray(R.array.nivel_1);
                String q0 = nivel1[ preguntaAct ];
                General_rsc(q0);
                if(preguntaAct ==10){
                    Nivel();
                    preguntaAct =0;

                }
               // Toast.makeText(Juego.this,"Valor: "+f,Toast.LENGTH_LONG).show();

                break;
            case 2:
                String[] nivel2 = getResources().getStringArray(R.array.nivel_2);
                String q0s = nivel2[preguntaAct];
                General_rsc(q0s);
                //Toast.makeText(Juego.this,"ValorX: "+f,Toast.LENGTH_LONG).show();
                if(preguntaAct ==16){
                    preguntaAct =0;
                    Nivel();
                }

                break;
            default:
                Tienda();
                break;
        }

    }
    private void General_rsc(String q0) {
                //String q0 = all_questions[preguntaAct];
                parts = q0.split(";");
                tvPantalla.setText(parts[0]);
                for (int i = 0; i < ids_answers.length; i++) {
                    RadioButton rb = (RadioButton) findViewById(ids_answers[i]);
                    String answ = parts[i + 1];
                    if (answ.charAt(0) == '*') {
                        Correctac_answer = i;
                        answ = answ.substring(1);
                    }
                    rb.setText(answ);
                }

//        String[] all_questions = getResources().getStringArray(R.array.nivel_1);
//        String q0 = all_questions[preguntaAct];
//        parts = q0.split(";");
//        tvPantalla.setText(parts[0]);
//        for (int i = 0; i < ids_answers.length; i++) {
//            RadioButton rb = (RadioButton) findViewById(ids_answers[i]);
//            String answ = parts[i + 1];
//            if (answ.charAt(0) == '*') {
//                Correctac_answer = i;
//                answ = answ.substring(1);
//            }
//            rb.setText(answ);
//        }


    }

    private void AsignarSonidoBTN() {
        findViewById(R.id.a).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mtd.SonidoGeneral(Juego.this,R.raw.boop);
            }
        });
        findViewById(R.id.b).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mtd.SonidoGeneral(Juego.this,R.raw.boop);
            }
        });
        findViewById(R.id.c).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mtd.SonidoGeneral(Juego.this,R.raw.boop);
            }
        });
        findViewById(R.id.d).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mtd.SonidoGeneral(Juego.this,R.raw.boop);
            }
        });
    }

    public void myRadioGrup(View v){

        int IdRadio = radioGrup.getCheckedRadioButtonId();
        IdSrc = findViewById(IdRadio);

        //String tv = tvPantalla.getText().toString();

        //Toast.makeText(MainActivity.this,"" + tv + IdSrc.getText(), Toast.LENGTH_LONG).show();

        //radioGrup.clearCheck(); /// para demarcar los radio butom
        //Juego(mtds.poscion); //reiniciar juego


    }


    public  void Tienda(){
        mtd.SonidoGeneral(Juego.this,R.raw.dialogo);
        mydialog.setContentView(R.layout.tienda);
        mydialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        mydialog.setCanceledOnTouchOutside(false);
        mydialog.setCancelable(false);
        mydialog.show();
        pauseTimer();
        int cop100 = Integer.parseInt(monedad.getText().toString());
        mydialog.findViewById(R.id.fbb).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mtd.musicaMoneda(mydialog.getContext());
                //mMoneda(puntosMoneda,500);
               // preg( pred,FRACE,img,uno,dos,tres);
                mydialog.dismiss();
                General_pregunta();
                resetTimer();
                mtd.SonidoGeneral(v.getContext(),R.raw.boop);
            }
        });

        mydialog.findViewById(R.id.tienda100).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //mtd.SonidoGeneral(Juego.this,R.raw.dialogo);
               // int cop100 = Integer.parseInt(monedad.getText().toString());
                if(cop100 >= 100){
                    if (findViewById(R.id.id_estrella1).getVisibility() == view.INVISIBLE){
                            findViewById(R.id.id_estrella1).setVisibility(view.VISIBLE);
                            int copV = cop100 - 100;
                            monedad.setText(String.valueOf(copV));
                            b =1;
                    }else{
                        if(findViewById(R.id.id_estrella2).getVisibility() == view.INVISIBLE){
                            findViewById(R.id.id_estrella2).setVisibility(view.VISIBLE);
                            int copV = cop100 - 100;
                            monedad.setText(String.valueOf(copV));
                            b =1;
                        }else{
                            if(findViewById(R.id.id_estrella3).getVisibility() == view.INVISIBLE){
                                findViewById(R.id.id_estrella3).setVisibility(view.VISIBLE);
                                int copV = cop100 - 100;
                                monedad.setText(String.valueOf(copV));
                                b =1;
                            }else{
                                Toast.makeText(getApplicationContext(),"Ya tienes las estrellas suficientes", Toast.LENGTH_LONG).show();
                            } } }

                    resetTimer();
                    mydialog.dismiss();

                }else {
                    MonedaInsuficiente();
                }
                //mydialog.dismiss();
            }
        });
        mydialog.findViewById(R.id.tienda300).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mtd.SonidoGeneral(Juego.this,R.raw.dialogo);
                int cop300 = Integer.parseInt(monedad.getText().toString());
                if(cop300 >= 300){
                    if(findViewById(R.id.id_estrella1).getVisibility() == view.INVISIBLE && findViewById(R.id.id_estrella2).getVisibility() == view.INVISIBLE){
                        findViewById(R.id.id_estrella1).setVisibility(view.VISIBLE);
                        findViewById(R.id.id_estrella2).setVisibility(view.VISIBLE);
                        int copV = cop300 - 300;
                        monedad.setText(String.valueOf(copV));
                        b =1;
                    }else {
                        if(findViewById(R.id.id_estrella2).getVisibility() == view.INVISIBLE && findViewById(R.id.id_estrella3).getVisibility() == view.INVISIBLE){
                            findViewById(R.id.id_estrella2).setVisibility(view.VISIBLE);
                            findViewById(R.id.id_estrella3).setVisibility(view.VISIBLE);
                            int copV = cop300 - 300;
                            monedad.setText(String.valueOf(copV));
                            b =1;
                        }else {
                            if(findViewById(R.id.id_estrella1).getVisibility() == view.INVISIBLE && findViewById(R.id.id_estrella3).getVisibility() == view.INVISIBLE){
                                findViewById(R.id.id_estrella1).setVisibility(view.VISIBLE);
                                findViewById(R.id.id_estrella3).setVisibility(view.VISIBLE);
                                int copV = cop300 - 300;
                                monedad.setText(String.valueOf(copV));
                                b =1;
                            }else {
                                Toast.makeText(getApplicationContext(),"Ya tienes las estrellas suficientes", Toast.LENGTH_LONG).show();
                     } } }
                    resetTimer();
                    mydialog.dismiss();
                }else {
                    MonedaInsuficiente();
                }
            }
        });
        mydialog.findViewById(R.id.tienda500).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mtd.SonidoGeneral(Juego.this,R.raw.dialogo);
                int cop500 = Integer.parseInt(monedad.getText().toString());
                if(cop500 >= 500){
                    if(findViewById(R.id.id_estrella3).getVisibility() == view.INVISIBLE){
                        int copV = cop500 - 500;
                        monedad.setText(String.valueOf(copV));
                        findViewById(R.id.id_estrella1).setVisibility(view.VISIBLE);
                        findViewById(R.id.id_estrella2).setVisibility(view.VISIBLE);
                        findViewById(R.id.id_estrella3).setVisibility(view.VISIBLE);
                        resetTimer();
                        mydialog.dismiss();
                        b =1;
                    }else {
                        Toast.makeText(getApplicationContext(),"Ya tienes las estrellas suficientes", Toast.LENGTH_LONG).show();
                        resetTimer();
                    }

                }else {
                    MonedaInsuficiente();
                }
                //mydialog.dismiss();
            }
        });

//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                mydialog.dismiss();
//
//            }
//        },2000);


    }

    public  void Nivel(){
        mtd.SonidoGeneral(Juego.this,R.raw.dialogo);
        mydialog.setContentView(R.layout.niveles);
        mydialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        mydialog.setCanceledOnTouchOutside(false);
        mydialog.setCancelable(false);
        mydialog.show();

        mydialog.findViewById(R.id.fbb).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mtd.musicaMoneda(mydialog.getContext());
                //mMoneda(puntosMoneda,500);
                // preg( pred,FRACE,img,uno,dos,tres);
                General_pregunta();
                resetTimer();
                mydialog.dismiss();
                mtd.SonidoGeneral(Juego.this,R.raw.boop);
            }
        });

        pauseTimer();

        mydialog.findViewById(R.id.id_monedad).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startTimer();
            }
        });

        CambiarIconosDeNivel();


    }

    private void CambiarIconosDeNivel() {
        mMonedas = Integer.parseInt(monedad.getText().toString());
       /// Toast.makeText(Juego.this,"P: "+mMonedas, Toast.LENGTH_LONG).show();

        if(mMonedas >=0){
            mydialog.findViewById(R.id.nivel1).setBackgroundResource(R.drawable.btn_pregunta);
        }
        if(mMonedas >= 50){ mydialog.findViewById(R.id.nivel2).setBackgroundResource(R.drawable.btn_pregunta);
        }
        if(mMonedas >= 200){ mydialog.findViewById(R.id.nivel3).setBackgroundResource(R.drawable.btn_pregunta);
        }
        if(mMonedas >= 300){ mydialog.findViewById(R.id.nivel4).setBackgroundResource(R.drawable.btn_pregunta);
        }
        if(mMonedas >= 400){ mydialog.findViewById(R.id.nivel5).setBackgroundResource(R.drawable.btn_pregunta);
        }
        if(mMonedas >= 500){ mydialog.findViewById(R.id.nivel6).setBackgroundResource(R.drawable.btn_pregunta);
        }
        if(mMonedas >= 600){ mydialog.findViewById(R.id.nivel7).setBackgroundResource(R.drawable.btn_pregunta);
        }
        if(mMonedas >= 700){ mydialog.findViewById(R.id.nivel8).setBackgroundResource(R.drawable.btn_pregunta);
        }
        if(mMonedas >= 800){ mydialog.findViewById(R.id.nivel9).setBackgroundResource(R.drawable.btn_pregunta);
        }
        if(mMonedas >= 900){ mydialog.findViewById(R.id.nivel10).setBackgroundResource(R.drawable.btn_pregunta);
        }
        if(mMonedas >= 1000){ mydialog.findViewById(R.id.nivel11).setBackgroundResource(R.drawable.btn_pregunta);
        }
        if(mMonedas >= 1100){ mydialog.findViewById(R.id.nivel12).setBackgroundResource(R.drawable.btn_pregunta);
        }
        if(mMonedas >= 1200){ mydialog.findViewById(R.id.nivel13).setBackgroundResource(R.drawable.btn_pregunta);
        }
        if(mMonedas >= 1300){ mydialog.findViewById(R.id.nivel14).setBackgroundResource(R.drawable.btn_pregunta);
        }
        if(mMonedas >= 1400){ mydialog.findViewById(R.id.nivel15).setBackgroundResource(R.drawable.btn_pregunta);
        }
        if(mMonedas >= 1500){ mydialog.findViewById(R.id.nivel16).setBackgroundResource(R.drawable.btn_pregunta);
        }
    }

    public void ValorNIvel(int moni){
        TextView vNivel = (TextView) findViewById(R.id.idNivel);
        if (moni >= 50){ vNivel.setText("02");   }
        if (moni >= 200){ vNivel.setText("03");  }
        if (moni >= 300){ vNivel.setText("04");  }
        if (moni >= 400){ vNivel.setText("05");  }
        if (moni >= 500){ vNivel.setText("06");  }
        if (moni >= 600){ vNivel.setText("07");  }
        if (moni >= 700){ vNivel.setText("08");  }
        if (moni >= 800){ vNivel.setText("09");  }
        if (moni >= 900){ vNivel.setText("10");  }
        if (moni >= 1000){ vNivel.setText("11"); }
        if (moni >= 1100){ vNivel.setText("12"); }
        if (moni >= 1200){ vNivel.setText("13"); }
        if (moni >= 1300){ vNivel.setText("14"); }
        if (moni >= 1400){ vNivel.setText("15"); }
        if (moni >= 1500){ vNivel.setText("16"); }
    }

    public void Comodin_Regalo(){
        mtd.SonidoGeneral(Juego.this,R.raw.dialogo);
       //Log.i("TAG","Valor: "+ Correctac_answer );

        for (int i = 0; i < ids_answers.length; i++) {
            RadioButton rb = (RadioButton) findViewById(ids_answers[i]);
            String answ = parts[i + 1];
            if (answ.charAt(0) == '*') {
                Correctac_answer = i;
                 answ = answ.substring(1);
               // Log.i("TAG","Valor: "+ answ );


                mydialog.setContentView(R.layout.comoding);
                mydialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                mydialog.setCanceledOnTouchOutside(false);
                mydialog.setCancelable(false);
                mydialog.show();

                ///diaP,diaR, diaC;
               /// diaP = mydialog.findViewById(R.id.dia_preg);
                diaR = mydialog.findViewById(R.id.ida_rep);
                diaC = mydialog.findViewById(R.id.dia_cerrar);

                diaC.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mtd.SonidoGeneral(Juego.this,R.raw.boop);
                        int cmo = Integer.parseInt(monedad.getText().toString());
                       int como = cmo - 50;
                        monedad.setText(String.valueOf(como));
                        mydialog.dismiss();
                    }
                });

//                diaP.setText(parts[0]); //la pregunta
                diaR.setText(answ); //la repuesta



            }
            rb.setText(answ);
            //Log.i("TAG","Valor: "+ answ );
        }



    }

    public void MonedaInsuficiente(){
        mtd.SonidoGeneral(Juego.this,R.raw.dialogo);
                pauseTimer();
                mydialog.setContentView(R.layout.moneda_insuficiente);
                mydialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                mydialog.setCanceledOnTouchOutside(false);
                mydialog.setCancelable(false);
                mydialog.show();

                diaC = mydialog.findViewById(R.id.dia_cerrar);

                diaC.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mtd.SonidoGeneral(Juego.this,R.raw.boop);
                        mydialog.dismiss();
                        resetTimer();
                    }
                });


    }


    public  void playgame(){

        mydialog.setContentView(R.layout.pay);
        mydialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        mydialog.setCanceledOnTouchOutside(false);
        mydialog.setCancelable(false);
        mydialog.show();


        mydialog.findViewById(R.id.iniciarJuego).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mydialog.dismiss();
                mtd.SonidoGeneral(Juego.this,R.raw.boop);
                startTimer();
                General_pregunta();
                LeerPref();
            }
        });
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                mydialog.dismiss();
//
//            }
//        },2000);


    }

    public  void UnaStrellaMeno(){
        Mtodos sdf = new Mtodos();
        sdf.SonidoGeneral(Juego.this,R.raw.error);
        mydialog.setContentView(R.layout.estrella_meno);
        mydialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        mydialog.setCanceledOnTouchOutside(false);
        mydialog.setCancelable(false);
        mydialog.show();
       //b = 1;

        switch (b){
            case 1:
                //Toast.makeText(Juego.this,"1", Toast.LENGTH_LONG).show();
                findViewById(R.id.id_estrella1).setVisibility(dview.INVISIBLE);
               // findViewById(R.id.id_estrella3).setBackgroundColor(R.color.my_color);
                b = 2;
                break;
            case 2:
                //Toast.makeText(Juego.this,"3", Toast.LENGTH_LONG).show();
                findViewById(R.id.id_estrella2).setVisibility(dview.INVISIBLE);
                b = 3;
                break;
            case 3:
                //Toast.makeText(Juego.this,"2", Toast.LENGTH_LONG).show();
                findViewById(R.id.id_estrella3).setVisibility(dview.INVISIBLE);
                b = 0;
                break;
            default:
                break;
        }

        mydialog.findViewById(R.id.id_estrella_meno).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mydialog.dismiss();
                General_pregunta();
                resetTimer();


            }
        });


        pauseTimer();
       // mCountDownTimer.cancel();
       // mTimerRunning = false;

        mydialog.findViewById(R.id.id_cerrarEstrella).setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onClick(View view) {
                mydialog.dismiss();
                General_pregunta();
                resetTimer();
                //mtd.SonidoGeneral(Juego.this,R.raw.boop);


            }
        });

//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                mydialog.dismiss();
//                General_pregunta();
//                resetTimer();
//
//                //playgame();
////                overridePendingTransition(0, 0);
////                //startActivity(getIntent());
////                overridePendingTransition(0, 0);
//                mtd.SonidoGeneral(Juego.this,R.raw.boop);
//            }
//        },6000);

    }

    public void BTN_Niveles(){
        mMonedas = Integer.parseInt(monedad.getText().toString());
       // ImageButton nivel = (ImageButton) findViewById(R.id.nivel1);
        ImageButton nivel = (ImageButton) findViewById(R.id.nivel1);
        Toast.makeText(Juego.this,"P: "+mMonedas, Toast.LENGTH_LONG).show();

        if(mMonedas == 100){
            Toast.makeText(Juego.this,"Pasate de nievel", Toast.LENGTH_LONG).show();
           // nivel.setBackground(ActivityCompat.getDrawable(getApplicationContext(), R.drawable.bg_a));
            //nivel.setBackground(ActivityCompat.getDrawable(getApplicationContext(), R.drawable.bg_a));
            nivel.setBackgroundResource(R.drawable.btn_pregunta);
        }
    }


    @Override
    protected void onStop() {
        //Toast.makeText(Juego.this,"Stooo", Toast.LENGTH_LONG).show();
        mtd.SonidoStop();
        super.onStop();
    }










}


